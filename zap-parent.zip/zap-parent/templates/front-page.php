<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?><!-------------THISWORKED---------------->

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
<article id="front-page" class="front-page page type-page status-publish hentry">
<div class="entry-content">
blah
<!------get zaps------>


	
</div>
</article>
		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php get_footer(); ?>